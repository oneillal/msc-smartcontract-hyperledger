Peer2Peer Library Contract.
----
"Paul Power" (the Lender) agrees to lend "Alan O'Neill" (the Borrower)
the itemName "The Da Vinci Code" ("9780552149518") which is currently graded as "M".

In the case of the late return of the item, the Borrower shall pay to Lender
a fine amounting to 0.25 (EUR) for every 1 days the item was returned overdue.
Any fractional part of a days is to be considered a full days. The total amount
of fine shall not however, exceed 50.0% of the total value of the borrowed item.

The contract provides a provision to waive late penalties in the event of
extenuating circumstances. This is wholely at the discretion of the Lender
and all decisions are final in this matter.